﻿namespace WebApplication11.model
{
    public class Contact
    {
        public Guid Id { get; set; }
        public string Name { get; set; }    
        public string email { get; set; }
        public long phone { get; set; }
        public string Address { get; set; }

    }
}
